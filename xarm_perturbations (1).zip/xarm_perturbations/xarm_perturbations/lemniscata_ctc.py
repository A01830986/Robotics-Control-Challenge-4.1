#!/usr/bin/env python3
import math
import time
import csv
import subprocess
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
import pinocchio as pin

class LemniscataCTCController(Node):
    def __init__(self):
        super().__init__("lemniscata_ctc_controller")

        # --- 1. CARGAR MODELO DINÁMICO (PINOCCHIO) ---
        try:
            raw_urdf = subprocess.check_output("ros2 param get robot_state_publisher robot_description", shell=True).decode('utf-8')
            start = raw_urdf.find('<robot')
            end = raw_urdf.rfind('</robot>') + 8
            urdf_str = raw_urdf[start:end].replace('\\n', '\n').replace('\\"', '"')
            self.model = pin.buildModelFromXML(urdf_str)
            self.data = self.model.createData()
            self.ee_frame_id = self.model.getFrameId("link_eef")
            self.get_logger().info('✅ Modelo Pinocchio cargado para CTC.')
        except Exception as e:
            self.get_logger().error(f'❌ Error URDF: {e}')
            return

        # --- 2. COMUNICACIÓN ---
        # Publicamos torques directos (Requisito Task B)
        self.torque_pub = self.create_publisher(Float64MultiArray, "/xarm/joint_torques", 10)
        self.joint_sub = self.create_subscription(JointState, "/joint_states", self._joint_callback, 10)

        # --- 3. PARÁMETROS DEL PDF ---
        # IK Parameters (Sección 5.1 del PDF)
        self.w_z = 2.5        # Peso Z-priority
        self.lam = 0.015      # Damping DLS
        self.k_task = 15.0    # Ganancia error tarea
        self.k_null = 1.5     # Posture stabilization
        self.q_home = np.array([0.0, -0.5, 0.5, 0.0, 0.0, 0.0])

        # CTC Gains (Sección 11.6 del PDF)
        self.Kp_ctc = 80.0
        self.Kd_ctc = 28.0

        # Trayectoria Lemniscata (de tu amigo)
        self.radius = 0.06
        self.frequency = 0.06

        self.q_act, self.qd_act, self.initialized = None, None, False
        self.start_time, self.center = None, None
        self.q_des_prev, self.qd_des_prev = None, None

        # --- 4. LOGGING (Task C) ---
        self.filename = f"trial_ctc_lemniscata_{int(time.time())}.csv"
        self.csv_file = open(self.filename, "w", newline="")
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(["time", "x_des", "y_des", "z_des", "x_act", "y_act", "z_act", "tau_1"])

        self.timer = self.create_timer(0.01, self._control_loop) # 100Hz

    def _joint_callback(self, msg):
        if len(msg.position) >= 6:
            self.q_act = np.array(msg.position[:6])
            self.qd_act = np.array(msg.velocity[:6])
            self.initialized = True

    def _lemniscata_target(self, t):
        # Trayectoria Lemniscata con Soft Start
        cx, cy, cz = self.center
        w = 2.0 * math.pi * self.frequency
        ramp = min(max(t / 3.0, 0.0), 1.0)
        
        # Posición deseada (p_des)
        x = cx + ramp * self.radius * math.sin(w * t)
        y = cy + ramp * self.radius * math.sin(w * t) * math.cos(w * t)
        z = cz
        
        # Velocidad deseada (p_dot_des) - Derivada de la posición
        vx = ramp * self.radius * w * math.cos(w * t)
        vy = ramp * self.radius * w * (math.cos(w * t)**2 - math.sin(w * t)**2)
        
        return np.array([x, y, z]), np.array([vx, vy, 0.0])

    def _control_loop(self):
        if not self.initialized: return
        
        if self.center is None:
            pin.forwardKinematics(self.model, self.data, self.q_act)
            self.center = self.data.oMf[self.ee_frame_id].translation.copy()
            self.start_time = time.time()
            self.q_des_prev = self.q_act.copy()
            self.qd_des_prev = np.zeros(6)
            return

        t = time.time() - self.start_time
        p_des, pd_des = self._lemniscata_target(t)

        # --- 5. IK: RESOLVED-RATE (Requisito 5.1 PDF) ---
        pin.forwardKinematics(self.model, self.data, self.q_act)
        pin.updateFramePlacements(self.model, self.data)
        p_act = self.data.oMf[self.ee_frame_id].translation
        J = pin.computeFrameJacobian(self.model, self.data, self.q_act, self.ee_frame_id, pin.ReferenceFrame.LOCAL_WORLD_ALIGNED)[:3, :]

        # DLS Pseudo-inverse con Pesos
        W = np.diag([1.0, 1.0, self.w_z])
        Jw = W @ J
        J_sharp = Jw.T @ np.linalg.inv(Jw @ Jw.T + (self.lam**2) * np.eye(3))
        
        # Nullspace y qd_des
        qd_null = (np.eye(6) - J_sharp @ Jw) @ (-self.k_null * (self.q_act - self.q_home))
        qd_des = J_sharp @ (pd_des + self.k_task * (p_des - p_act)) + qd_null
        
        # Integración para q_des y derivación para qdd_des
        q_des = self.q_des_prev + qd_des * 0.01
        qdd_des = (qd_des - self.qd_des_prev) / 0.01

        # --- 6. CTC: CONTROL POR TORQUE (Requisito 11.6 PDF) ---
        # Error en espacio articular
        e_q = q_des - self.q_act
        ed_q = qd_des - self.qd_act
        
        # Ley de control (Aceleración de comando)
        aq = qdd_des + self.Kp_ctc * e_q + self.Kd_ctc * ed_q
        
        # Dinámica Inversa de Pinocchio (RNEA)
        tau = pin.rnea(self.model, self.data, self.q_act, self.qd_act, aq)
        
        # Saturation y Envío
        self.torque_pub.publish(Float64MultiArray(data=np.clip(tau, -10, 10).tolist()))

        # Guardar Log
        self.csv_writer.writerow([t, *p_des, *p_act, tau[0]])
        self.q_des_prev, self.qd_des_prev = q_des.copy(), qd_des.copy()

def main(args=None):
    rclpy.init(args=args)
    node = LemniscataCTCController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.csv_file.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__": main()
