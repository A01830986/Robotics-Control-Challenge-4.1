import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import numpy as np

class CircleController(Node):
    def __init__(self):
        super().__init__('circle_controller')
        self.publisher_ = self.create_publisher(Twist, '/servo_server/delta_twist_cmds', 10)
        
        # Parámetros configurables
        self.declare_parameter('radius', 0.05)         # 5 cm de radio
        self.declare_parameter('omega', 0.5)          # Velocidad angular (rad/s)
        self.declare_parameter('publish_rate', 0.01)   # 100Hz para suavidad
        
        self.radius = self.get_parameter('radius').value
        self.omega = self.get_parameter('omega').value
        self.timer = self.create_timer(self.get_parameter('publish_rate').value, self.timer_callback)
        self.start_time = self.get_clock().now().nanoseconds / 1e9

    def timer_callback(self):
        t = (self.get_clock().now().nanoseconds / 1e9) - self.start_time
        
        msg = Twist()
        
        # Velocidades lineales en el plano paralelo al suelo (XY)
        # Derivada de x = R*cos(w*t) -> vx = -R*w*sin(w*t)
        # Derivada de y = R*sin(w*t) -> vy = R*w*cos(w*t)
        msg.linear.x = -self.radius * self.omega * np.sin(self.omega * t)
        msg.linear.y = self.radius * self.omega * np.cos(self.omega * t)
        msg.linear.z = 0.0  # Mantiene la altura constante (paralelo al suelo)

        # Mantenemos la orientación fija (sin rotaciones en la muñeca)
        msg.angular.x = 0.0
        msg.angular.y = 0.0
        msg.angular.z = 0.0

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = CircleController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
