import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped, Point
from tf2_ros import TransformException, Buffer, TransformListener
import numpy as np
import csv
import time

class PositionController(Node):
    def __init__(self):
        super().__init__('position_controller')

        # Parámetros del PID y configuración
        self.declare_parameters(namespace='', parameters=[
            ('kp', [2.5, 2.5, 2.5]), ('ki', [0.0, 0.0, 0.0]), ('kd', [0.6, 0.6, 0.6]),
            ('max_speed', 0.10), ('deadband', 0.002),
            ('output_topic', '/servo_server/delta_twist_cmds'),
            ('input_topic', '/target_point')
        ])

        # Setup de TF y Suscripciones
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.target_sub = self.create_subscription(Point, self.get_parameter('input_topic').value, self.target_callback, 10)
        self.cmd_pub = self.create_publisher(TwistStamped, self.get_parameter('output_topic').value, 10)

        # Variables de control
        self.target_pos = np.array([0.0, 0.0, 0.0])
        self.error_integral = np.array([0.0, 0.0, 0.0])
        self.prev_error = np.array([0.0, 0.0, 0.0])
        self.last_time = self.get_clock().now()

        # --- LOGGING ---
        filename = f"lab_data_{int(time.time())}.csv"
        self.csv_file = open(filename, 'w', newline='')
        self.writer = csv.writer(self.csv_file)
        self.writer.writerow(['time', 'x_des', 'y_des', 'z_des', 'x_act', 'y_act', 'z_act', 'error_norm'])
        self.get_logger().info(f'Guardando datos en: {filename}')

        self.timer = self.create_timer(0.02, self.control_loop) # 50Hz

    def target_callback(self, msg):
        self.target_pos = np.array([msg.x, msg.y, msg.z])

    def control_loop(self):
        try:
            # 1. Posición actual (Real) desde TF
            t = self.tf_buffer.lookup_transform('link_base', 'link_eef', rclpy.time.Time())
            curr_pos = np.array([t.transform.translation.x, t.transform.translation.y, t.transform.translation.z])

            # 2. Cálculo del Error
            error = self.target_pos - curr_pos
            for i in range(3):
                if abs(error[i]) < self.get_parameter('deadband').value: error[i] = 0.0

            # 3. PID logic
            now = self.get_clock().now()
            dt = (now - self.last_time).nanoseconds / 1e9
            if dt <= 0: return

            p_term = np.array(self.get_parameter('kp').value) * error
            self.error_integral += error * dt
            i_term = np.array(self.get_parameter('ki').value) * self.error_integral
            d_term = np.array(self.get_parameter('kd').value) * (error - self.prev_error) / dt

            u = p_term + i_term + d_term

            # Saturación y Anti-windup
            v_norm = np.linalg.norm(u)
            if v_norm > self.get_parameter('max_speed').value:
                u = (u / v_norm) * self.get_parameter('max_speed').value
                self.error_integral -= error * dt 

            # 4. Publicar
            cmd = TwistStamped()
            cmd.header.stamp = now.to_msg()
            cmd.header.frame_id = 'link_base'
            cmd.twist.linear.x, cmd.twist.linear.y, cmd.twist.linear.z = u[0], u[1], u[2]
            self.cmd_pub.publish(cmd)

            # 5. Guardar en CSV
            self.writer.writerow([now.nanoseconds/1e9, *self.target_pos, *curr_pos, np.linalg.norm(error)])

            self.prev_error, self.last_time = error, now

        except TransformException:
            pass

    def __del__(self):
        self.csv_file.close()

def main():
    rclpy.init()
    rclpy.spin(PositionController())
    rclpy.shutdown()
